NOTE: This page(index.html) is  completely build from scratch 
with pure HTML code and CSS.
(No framework has been used)
Thankyou!!